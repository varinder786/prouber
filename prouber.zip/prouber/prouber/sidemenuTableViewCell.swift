//
//  sidemenuTableViewCell.swift
//  prouber
//
//  Created by Joban Dhot on 2018-10-03.
//  Copyright © 2018 Joban Dhot. All rights reserved.
//

import UIKit

class sidemenuTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
