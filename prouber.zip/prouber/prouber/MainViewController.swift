//
//  MainViewController.swift
//  prouber
//
//  Created by Joban Dhot on 2018-10-01.
//  Copyright © 2018 Joban Dhot. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

   
    @IBOutlet weak var sidemenu: UIBarButtonItem!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        if self.revealViewController() != nil {
            sidemenu.target = self.revealViewController()
            sidemenu.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
