//
//  proViewController.swift
//  prouber
//
//  Created by Joban Dhot on 2018-10-03.
//  Copyright © 2018 Joban Dhot. All rights reserved.
//

import UIKit

class proViewController: UIViewController {

    import UIKit
    
    var selecyedimgfrompicker: UIImage?
    
    let defaults = UserDefaults(suiteName: "com.Service.Ontario")
    class ProfileViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
        @IBAction func SaveButton(_ sender: Any) {
            
            
            let alert = UIAlertController(title: "Saved!!", message: "All Information Saved Successfully", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
            
            
            self.present(alert, animated: true)
            
            
            
        }
        
        @IBOutlet weak var selectImage: UIButton!
        @IBAction func selectImage(_ sender: Any) {
            
            
            let myPickerController = UIImagePickerController()
            
            myPickerController.delegate = self;
            myPickerController.allowsEditing = true
            myPickerController.sourceType = UIImagePickerControllerSourceType.photoLibrary
            
            self.present(myPickerController, animated: true, completion: nil)
        }
        
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]){
            
            print("here is info",info)
            ProfileImage.image = info[UIImagePickerControllerOriginalImage] as? UIImage
            ProfileImage.backgroundColor = UIColor.clear
            self.dismiss(animated: true, completion: nil)
            
            
            
            if let editedimage = info["UIImagePickerControllerEditedImage"] as? UIImage{
                
                selecyedimgfrompicker = editedimage
                
                
            }
                
            else if let orignalimage = info["UIImagePickerControllerOriginalImage"] as? UIImage  {
                
                selecyedimgfrompicker = orignalimage
                
            }
            if selecyedimgfrompicker != nil{
                
                ProfileImage.image = selecyedimgfrompicker
                
            }
            
            
            //upload()
            
            self.selectImage.isEnabled = true
            self.selectImage.isHidden = true
            
        }
        
        
        
        
        
        
        
        @IBOutlet weak var firstname: UITextField!
        @IBOutlet weak var lastname: UITextField!
        @IBOutlet weak var ProfileImage: UIImageView!
        override func viewDidLoad() {
            super.viewDidLoad()
            imageproperties()
            //getdata()
            // Do any additional setup after loading the view.
        }
        
        
        
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        @IBOutlet weak var showsavedimg: UIImageView!
        
        func imageproperties(){
            
            super.viewDidLoad()
            ProfileImage.layer.borderColor = UIColor.gray.cgColor
            ProfileImage.layer.borderWidth = 2
            self.ProfileImage.layer.cornerRadius = self.ProfileImage.frame.size.width / 2;
            self.ProfileImage.clipsToBounds = true;
        }
        func saveData(){
            
            
            // defaults?.set(firstname, forKey: "savedata")
            
            //  defaults?.set(lastname, forKey: "savedata")
            // defaults?.synchronize()
            UserDefaults.standard.set(firstname.text, forKey: "savedfirstname")
            let fdata = UserDefaults.standard.object(forKey: "savedfirstname")
            firstname.text = ""
            firstname.text = (fdata as! String)
            
            
            UserDefaults.standard.set(lastname.text, forKey: "savedlastname")
            let ldata = UserDefaults.standard.object(forKey: "savedlastname")
            lastname.text = ""
            lastname.text = (ldata as! String)
            
            
            let  imageData: NSData = UIImagePNGRepresentation(selecyedimgfrompicker!)! as NSData
            
            ////save image
            UserDefaults.standard.set(imageData, forKey: "savedImage")
            let data = UserDefaults.standard.object(forKey: "savedImage") as! NSData
            
            showsavedimg.image = UIImage(data: data as Data)
            
        }
        
        
        
        
        @IBOutlet weak var lname: UITextField!
        @IBOutlet weak var fname: UITextField!
        
        
        @IBAction func saveBtn(_ sender: Any) {
            saveData()
            ProfileImage.image = nil
        }
        override func viewDidAppear(_ animated: Bool) {
            if var x = UserDefaults.standard.object(forKey:  "savedfirstname") as? String  {
                
                fname.text = x
                
            }
            if var y = UserDefaults.standard.object(forKey:  "savedlastname") as? String{
                
                lname.text = y
                
                
            }
            if var data1 = UserDefaults.standard.object(forKey: "savedImage") as? NSData{
                
                showsavedimg.image = UIImage(data: data1 as Data)
                
                
            }
            
        }
        
}

